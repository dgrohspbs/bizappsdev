WITH TelemetryData AS 
(
-- Web Simulator Devices
SELECT
     Stream.DeviceID,
     'Temperature' AS ReadingType,
     Stream.Temperature AS Reading,
     Stream.EventToken AS EventToken,
     Stream.EventEnqueuedUtcTime AS [time]
FROM IoTStream Stream

UNION

-- MX Chip
SELECT
     GetMetadataPropertyValue(Stream, '[IoTHUB].[ConnectionDeviceId]') as DeviceID,
     'Temperature' AS ReadingType,
     Stream.temp AS Reading,
     GetMetadataPropertyValue (Stream, 'EventId') as EventToken,
     Stream.EventEnqueuedUtcTime AS [time]
FROM IoTStream Stream 

UNION

-- Particle Device
SELECT
     Stream.device_id as DeviceID,
     'Temperature' AS ReadingType,
     CAST(Stream.data as float) AS reading,
     Stream.EventToken AS EventToken,
     CAST(Stream.published_at as datetime) AS [time] 
     
FROM IoTStream Stream
),

-- Finds Max Value in 30 second window  
MaxInWindow AS
(
SELECT
    TopOne() OVER (ORDER BY Reading DESC) AS telemetryEvent
FROM
    TelemetryData 
WHERE 
	DeviceId IS NOT NULL
GROUP BY 
    DeviceId, TumblingWindow(second, 30)
)

-- Insert data into the Power BI Output 
SELECT telemetryEvent.DeviceId,
    telemetryEvent.ReadingType,
    telemetryEvent.Reading,
    telemetryEvent.EventToken,
    telemetryEvent.Time
INTO [CallStream-PowerBI]
FROM MaxInWindow
