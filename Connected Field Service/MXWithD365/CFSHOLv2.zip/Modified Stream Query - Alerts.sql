WITH AlertData AS 
(
-- Web Simulator Devices
SELECT
     Stream.DeviceID,
     'Temperature' AS ReadingType,
     Stream.Temperature AS Reading,
     Stream.EventToken AS EventToken,
     Ref.Temperature AS Threshold,
     Ref.TemperatureRuleOutput AS RuleOutput,
     Stream.EventEnqueuedUtcTime AS [time]
FROM IoTStream Stream
JOIN DeviceRulesBlob Ref ON Ref.DeviceType = 'Thermostat'
WHERE
     Stream.EventToken IS NOT NULL AND Stream.Temperature > Ref.Temperature 

UNION

-- MX Chip
SELECT
     GetMetadataPropertyValue(Stream, '[IoTHUB].[ConnectionDeviceId]') as DeviceID,
     'Temperature' AS ReadingType,
     Stream.temp AS Reading,
     GetMetadataPropertyValue (Stream, 'EventId') as EventToken,
     Ref.Temperature AS Threshold,
     Ref.TemperatureRuleOutput AS RuleOutput,
     Stream.EventEnqueuedUtcTime AS [time]
FROM IoTStream Stream 
JOIN DeviceRulesBlob Ref ON Ref.DeviceType = 'Thermostat'
WHERE
     Stream.temp IS NOT NULL AND Stream.temp > Ref.Temperature

UNION

-- Particle Device
SELECT
     Stream.device_id as DeviceID,
     'Temperature' AS ReadingType,
     CAST(Stream.data as float) AS reading,
     Stream.EventToken AS EventToken,
     Ref.Temperature AS Threshold,
     Ref.TemperatureRuleOutput AS RuleOutput,
     CAST(Stream.published_at as datetime) AS [time] 
     
FROM IoTStream Stream
JOIN DeviceRulesBlob Ref ON Ref.DeviceType = 'Thermostat'
WHERE
     CAST(Stream.data as float) > Ref.Temperature AND Stream.Event = 'temperature'
)

-- Insert data into the "Alerts" Service Bus Queue 
SELECT data.DeviceId,
    data.ReadingType,
    data.Reading,
    data.EventToken,
    data.Threshold,
    data.RuleOutput,
    data.Time
INTO AlertsQueue
FROM AlertData data
WHERE LAG(data.DeviceID) OVER (PARTITION BY data.DeviceId, data.Reading, data.ReadingType LIMIT DURATION(minute, 1)) IS NULL

